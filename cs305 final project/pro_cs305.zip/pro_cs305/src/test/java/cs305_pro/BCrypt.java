package cs305_pro;

public class BCrypt {

    public static Object gensalt() {
        return null;
    }

    public static String hashpw(String password, Object gensalt) {
        return null;
    }

}

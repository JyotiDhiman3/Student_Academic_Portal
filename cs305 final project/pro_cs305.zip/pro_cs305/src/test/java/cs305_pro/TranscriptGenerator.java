package cs305_pro;

public class TranscriptGenerator {

    public void generateTranscript(String emailId) {
    }

    public void viewGradesOfAllStudents() {
    }

}

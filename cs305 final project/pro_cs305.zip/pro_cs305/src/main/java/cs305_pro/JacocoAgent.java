package cs305_pro;

public class JacocoAgent {
    public static void main(String[] args) {
        System.setProperty("jacoco-agent.destfile", "/path/to/jacoco.exec");
    }
}


package net.codejava.jdbc;

public @interface Test {

}

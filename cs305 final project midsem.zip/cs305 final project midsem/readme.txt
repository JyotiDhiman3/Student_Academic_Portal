// NAME  : JYOTI DHIMAN
// ENTRY NUMBER : 2020CSB1092

How to compile my java code?
My java project contains a loginCLI.java file. Simply compile and run this java file. All the other files
studentcli.java , facultycli.java and acadofficecli.java will be run through this main loginCLI.java file only.
ContactProgram.java file is just made to check if the java project is getting connected to postgresql database 
or not.

ASSUMPTIONS:
I have made some assumptions while doing this project.
1. The project does not contain a global date and time. If some student wants to see if he/she is eligible for
   graduation ,then the current semester will be taken from the user only. Whenever any discrepancy has arisen related 
   to date and time, I have taken the current semester running from the user only.


package cs305_pro;

public @interface AfterAll {

}
